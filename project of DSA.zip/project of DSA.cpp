#include <iostream>
#include <string>   
#include <iomanip>  

using namespace std;
 
float get_dist(float x1, float y1, float x2, float y2) {
    float n = (x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1), x = n, y = 1;
    if (n == 0) return 0;
    while (x - y > 0.01) { x = (x + y) / 2; y = n / x; }
    return x;
}

void copy_str(char* d, const char* s) {
    int i = 0; while (s[i] && i < 49) { d[i] = s[i]; i++; } d[i] = '\0';
}

struct Road { int to; float w; Road* next; };
struct City { int id; char name[50]; float x, y; Road* roads; };
struct Edge { int u, v; float w; };
struct Graph { City cities[8]; int cityCount; Edge edges[30]; int edgeCount; };

struct MapEntry { int key; float fVal; int iVal; MapEntry* next; };
struct HashMap { MapEntry* table[10]; };
MapEntry* map_get(HashMap& m, int k) {
    int h = (k < 0 ? -k : k) % 10; MapEntry* c = m.table[h];
    while (c) { if (c->key == k) return c; c = c->next; }
    MapEntry* n = new MapEntry{ k, 1e9f, -1, m.table[h] };
    return m.table[h] = n;
}

struct HeapNode { float dist; int u, v; };
struct MinHeap { HeapNode data[100]; int size; };
void heap_push(MinHeap& h, float d, int u, int v = -1) {
    int c = h.size++;
    h.data[c] = { d, u, v };
    while (c > 0 && h.data[(c - 1) / 2].dist > h.data[c].dist) {
        HeapNode t = h.data[c]; h.data[c] = h.data[(c - 1) / 2]; h.data[(c - 1) / 2] = t;
        c = (c - 1) / 2;
    }
}
HeapNode heap_pop(MinHeap& h) {
    HeapNode top = h.data[0]; h.data[0] = h.data[--h.size];
    int p = 0;
    while (2 * p + 1 < h.size) {
        int j = 2 * p + 1;
        if (j + 1 < h.size && h.data[j + 1].dist < h.data[j].dist) j++;
        if (h.data[p].dist <= h.data[j].dist) break;
        HeapNode t = h.data[p]; h.data[p] = h.data[j]; h.data[j] = t; p = j;
    }
    return top;
}

void add_road(Graph& g, int u, int v) {
    float w = get_dist(g.cities[u].x, g.cities[u].y, g.cities[v].x, g.cities[v].y);
    g.cities[u].roads = new Road{ v, w, g.cities[u].roads };
    g.cities[v].roads = new Road{ u, w, g.cities[v].roads };
    g.edges[g.edgeCount++] = { u, v, w };
}



void run_dijkstra(Graph& g, int start, int dest) {
    HashMap dists = { 0 }, parent = { 0 }, vis = { 0 }; MinHeap pq = { 0 };
    for (int i = 0; i < g.cityCount; i++) map_get(dists, i)->fVal = 1e9f;
    map_get(dists, start)->fVal = 0; heap_push(pq, 0, start);

    while (pq.size > 0) {
        int u = heap_pop(pq).u;
        if (map_get(vis, u)->iVal == 1) continue;
        map_get(vis, u)->iVal = 1;
        for (Road* r = g.cities[u].roads; r; r = r->next) {
            float dU = map_get(dists, u)->fVal;
            if (dU + r->w < map_get(dists, r->to)->fVal) {
                map_get(dists, r->to)->fVal = dU + r->w;
                map_get(parent, r->to)->iVal = u;
                heap_push(pq, map_get(dists, r->to)->fVal, r->to);
            }
        }
    }
    if (map_get(dists, dest)->fVal > 1e8) { cout << "No path exists!\n"; return; }

    int path[8], count = 0, curr = dest;
    while (curr != start && curr != -1) { path[count++] = curr; curr = map_get(parent, curr)->iVal; }

    cout << "[Dijkstra Shortest Path Results]"<<endl;
    cout << "Route: " << g.cities[start].name;
    for (int i = count - 1; i >= 0; i--)
    cout << " -> " << g.cities[path[i]].name<<endl;
    cout << "Intermediate Cities: " << (count > 1 ? count - 1 : 0) << " | Distance: " << map_get(dists, dest)->fVal << " km" << endl;
}

void run_floyd_warshall(Graph& g, int src, int dst) {
    float d[8][8]; int next[8][8];
    for (int i = 0; i < 8; i++) {
        for (int j = 0; j < 8; j++) {
            d[i][j] = (i == j) ? 0 : 1e9f;
            next[i][j] = -1;
        }
    }
    for (int i = 0; i < g.edgeCount; i++) {
        int u = g.edges[i].u, v = g.edges[i].v;
        d[u][v] = d[v][u] = g.edges[i].w;
        next[u][v] = v; next[v][u] = u;
    }

    for (int k = 0; k < 8; k++)
        for (int i = 0; i < 8; i++)
            for (int j = 0; j < 8; j++)
                if (d[i][k] + d[k][j] < d[i][j]) { d[i][j] = d[i][k] + d[k][j]; next[i][j] = next[i][k]; }

    if (next[src][dst] == -1) { cout << "No path exists!<<endl"; 
    return;
    }

    cout << "[Floyd-Warshall All-Pairs Results]"<<endl;
    cout << "Route: " << g.cities[src].name;
    int curr = src, inter = 0;
    while (curr != dst) {
        curr = next[curr][dst];
        cout << " -> " << g.cities[curr].name;
        if (curr != dst) inter++;
    }
    cout << "Intermediate Cities: " << inter << " | Distance: " << d[src][dst] << " km"<<endl;
}

bool find_mst_path(int curr, int target, Road* mstAdj[], int path[], int& count, bool vis[]) {
    vis[curr] = true; 
    path[count++] = curr;
    if (curr == target) return true;
    for (Road* r = mstAdj[curr]; r; r = r->next)
        if (!vis[r->to] && find_mst_path(r->to, target, mstAdj, path, count, vis)) return true;
    count--;
    return false;
}

void query_mst_path(Graph& g, Edge mstEdges[], int edgeCount) {
    int s, d; cout << "\nSelect cities for MST trip:\nSource ID: "<<endl;
    cin >> s;
    cout << "Dest ID: "<<endl; 
    cin >> d;
    Road* mstAdj[8] = { nullptr };
    for (int i = 0; i < edgeCount; i++) {
        mstAdj[mstEdges[i].u] = new Road{ mstEdges[i].v, mstEdges[i].w, mstAdj[mstEdges[i].u] };
        mstAdj[mstEdges[i].v] = new Road{ mstEdges[i].u, mstEdges[i].w, mstAdj[mstEdges[i].v] };
    }
    int path[8], count = 0; bool vis[8] = { false };
    if (find_mst_path(s, d, mstAdj, path, count, vis)) {
        cout << "MST Route: " << g.cities[path[0]].name;
        for (int i = 1; i < count; i++)
            cout << " -> " << g.cities[path[i]].name << endl;
        cout << "Cities lying between: " << (count > 2 ? to_string(count - 2) : "0") << endl;
    }
}


void run_prim(Graph& g) {
    HashMap vis = { 0 };
    MinHeap pq = { 0 }; 
    Edge mstEdges[8];
    int mstCount = 0;
    float totalWeight = 0; heap_push(pq, 0, 0, -1);
    cout << "Prim's Step-by-Step Cycle Check"<<endl;
    cout << left << setw(25) << "Edge Candidate" << setw(15) << "Status" << "Reason" << endl;
    
    while (pq.size > 0) {
        HeapNode e = heap_pop(pq);
        string edgeName = (e.v == -1) ? "Start (Islamabad)" : string(g.cities[e.v].name) + "-" + string(g.cities[e.u].name);
        if (map_get(vis, e.u)->iVal == 1) {
            cout << left << setw(25) << edgeName << setw(15) << "REJECTED" << "City " << g.cities[e.u].name << " is already in MST (Cycle)" << endl;
            continue;
        }
        map_get(vis, e.u)->iVal = 1;
        if (e.v != -1) {
            cout << left << setw(25) << edgeName << setw(15) << "ACCEPTED" << "Connecting new city: " << g.cities[e.u].name << endl;
            mstEdges[mstCount++] = { e.v, e.u, e.dist }; totalWeight += e.dist;
        }
        else cout << left << setw(25) << edgeName << setw(15) << "ACCEPTED" << "Starting point of the tree" << endl;
        for (Road* r = g.cities[e.u].roads; r; r = r->next)
            if (map_get(vis, r->to)->iVal != 1) heap_push(pq, r->w, r->to, e.u);
    }
    
    cout << "Total MST Weight: " << totalWeight << " km"<<endl;
    query_mst_path(g, mstEdges, mstCount);
}

int find_set(int i, int p[]) { return (p[i] == i) ? i : p[i] = find_set(p[i], p); }

void run_kruskal(Graph& g) {
    for (int i = 0; i < g.edgeCount - 1; i++)
        for (int j = 0; j < g.edgeCount - i - 1; j++)
            if (g.edges[j].w > g.edges[j + 1].w) {
                Edge t = g.edges[j]; g.edges[j] = g.edges[j + 1]; g.edges[j + 1] = t; }
    int p[8]; 
    for (int i = 0; i < 8; i++)
        p[i] = i;
    Edge mstEdges[8]; int mstCount = 0; float totalWeight = 0;
    cout << " Kruskal's Step-by-Step Cycle Check \n";
    cout << left << setw(25) << "Edge" << setw(15) << "Status" << "Reason" << endl;
    cout << endl;
    for (int i = 0; i < g.edgeCount; i++) {
        int rU = find_set(g.edges[i].u, p),
            rV = find_set(g.edges[i].v, p);
        string edgeName = string(g.cities[g.edges[i].u].name) + "-" + string(g.cities[g.edges[i].v].name);
        if (rU != rV) {
            cout << left << setw(25) << edgeName << setw(15) << "ACCEPTED" << "Merging Group " << rU << " & " << rV << endl;
            p[rU] = rV; mstEdges[mstCount++] = g.edges[i]; totalWeight += g.edges[i].w;
        }
        else cout << left << setw(25) << edgeName << setw(15) << "REJECTED" << "Both cities already in Group " << rU << " (Cycle)" << endl;
    }
    cout <<endl;
    cout << "Total MST Weight: " << totalWeight << " km"<<endl;
    query_mst_path(g, mstEdges, mstCount);
}

int main() {
    Graph g = { 0 };
    auto add = [&](int i, const char* n, float x, float y) {
        g.cities[g.cityCount] = { i, "", x, y, nullptr };
        copy_str(g.cities[g.cityCount].name, n); g.cityCount++;
    };

    add(0, "Islamabad", 715, 200); add(1, "Lahore", 815, 300);
    add(2, "Karachi", 570, 620);   add(3, "Peshawar", 650, 190);
    add(4, "Quetta", 470, 370);    add(5, "Sukkur", 600, 480);
    add(6, "Hyderabad", 580, 580); add(7, "Multan", 710, 390);

    add_road(g, 3, 0); add_road(g, 3, 4); add_road(g, 4, 2);
    add_road(g, 5, 6); add_road(g, 6, 2); add_road(g, 5, 7);
    add_road(g, 7, 1); add_road(g, 1, 0);

    cout << "PAKISTAN CITY NETWORK (8 CITIES)"<<endl;
    for (int i = 0; i < g.cityCount; i++) cout << "[" << i << "] " << g.cities[i].name << endl;

    cout << "1. Shortest Path \n2. MST (Connect All Cities)Choice: ";
    int m; cin >> m;
    if (m == 1) {
        int s, d, algo;
        cout << "Source ID: "; cin >> s; cout << "Dest ID: "; cin >> d;
        cout << "Algorithm (1. Dijkstra, 2. Floyd-Warshall): "; cin >> algo;
        if (algo == 1) run_dijkstra(g, s, d);
        else
            run_floyd_warshall(g, s, d);
    }
    else {
        int a; cout << "Select MST Algorithm (1. Prim's, 2. Kruskal's): "; cin >> a;
        if (a == 1)
            run_prim(g); else run_kruskal(g);
    }
    return 0;
}